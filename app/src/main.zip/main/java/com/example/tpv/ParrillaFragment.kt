package com.example.tpv

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.activityViewModels
import com.example.tpv.data.api.RetrofitClient
import com.example.tpv.data.model.Pedido
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.widget.Toast
import android.util.Log
import android.view.Gravity
import android.widget.GridLayout
import com.example.tpv.data.model.FamiliaProducto
import com.example.tpv.viewModels.PedidoViewModel
import com.example.tpv.viewModels.ProductosViewModel
import com.google.android.material.button.MaterialButton
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.collections.component1
import kotlin.collections.component2
import kotlin.properties.Delegates

class ParrillaFragment : Fragment() {

    private val pedidoViewModel: PedidoViewModel by activityViewModels()
    private val productosViewModel: ProductosViewModel by activityViewModels()

    private lateinit var layoutCategorias: GridLayout
    private lateinit var layoutProductos: GridLayout
    private lateinit var layoutTicketItems: LinearLayout

    private var mesaActual: String = "sin mesa"
    private var salaActual: String = "sin sala"

    private var idLocal by Delegates.notNull<Int>()
    private lateinit var nombreLocal:String
    private lateinit var terminal:String
    private lateinit var camarero:String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_parrilla, container, false)
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

       /* val nuevoTerminal = RedCLSLoginTransPetNuevoTerminal()
        nuevoTerminal.fuc = "057678260"      // FUC del comercio
        nuevoTerminal.terminal = 2           // Número de terminal como Int
        nuevoTerminal.tipo = 2               // Tipo: 2 = PC (físico)


        // Lanzar coroutine en hilo IO para operaciones de red
        lateinit var terminal: RedCLSTerminalData

        fun mostrarResultado(resultado:RedCLSTerminalData){
            terminal = resultado
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Tu código de red aquí (ejemplo)
                val response = RedCLSMerchantConfigurationManager.addTerminal(context, nuevoTerminal)

                if (response.code == 0) {
                    Log.d("LoginTrans", "Solicitud enviada. Esperando activación del terminal.")
                    val loginResponse = RedCLSMerchantConfigurationManager.loginWithoutUser(context)
                    Log.d("respuesta login", loginResponse.toString())
                    lateinit var terminal: RedCLSTerminalData
                    // Obtenemos el primer comercio
                    val merchant = loginResponse.merchantList.firstOrNull()
                    if (merchant != null && merchant.terminalList.isNotEmpty()) {
                        terminal = merchant.terminalList[0]
                        Log.d("Terminal", "Terminal cargado: ${terminal.terminal}")
                        withContext(Dispatchers.Main) {
                            // Aquí sí puedes usar resultado para actualizar UI o lo que sea
                            mostrarResultado(terminal)
                        }
                    } else {
                        Log.e("LoginTrans", "No se encontraron terminales.")
                    }
                } else {
                    Log.e("LoginTrans", "Error: ${response.desc}")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }*/

        val prefs = requireContext().getSharedPreferences("TPV_PREFS", Context.MODE_PRIVATE)
        idLocal = prefs.getInt("local_id", -1)
        nombreLocal = prefs.getString("local_nombre", null).toString()
        terminal = prefs.getString("terminal", null).toString()
        camarero = prefs.getString("camarero", null).toString()


        layoutCategorias = view.findViewById(R.id.layoutCategorias)
        layoutProductos = view.findViewById(R.id.layoutProductos)
        layoutTicketItems = view.findViewById(R.id.layoutTicketItems)

        // Cargar datos del ViewModel (que a su vez los carga de la base de datos)
        productosViewModel.cargarFamilias(prefs.getString("dbId", "cloud").toString(), nombreLocal)
        productosViewModel.cargarProductos(prefs.getString("dbId", "cloud").toString(), nombreLocal)

        // Observar familias y mostrarlas como botones categorías
        productosViewModel.familias.observe(viewLifecycleOwner) { familias ->
            mostrarCategorias(familias)
            familias.firstOrNull()?.let { mostrarProductosDeFamilia(it.Nombre) }
        }

        // Actualizamos la UI del ticket cuando cambian productos en la mesa
        pedidoViewModel.productosPorMesa.observe(viewLifecycleOwner) {
            actualizarUIProductos()
        }

        // Actualizar mesa seleccionada
        pedidoViewModel.mesaSeleccionada.observe(viewLifecycleOwner) { mesa ->
            mesaActual = mesa ?: "sin mesa"

            // Actualizar el TextView con el nombre de la mesa
            salaActual = pedidoViewModel.salaSeleccionada.value ?: "sin sala"
            val textMesaView = view.findViewById<TextView>(R.id.textMesa)
            textMesaView?.text = "$salaActual: $mesaActual"

            actualizarUIProductos()
        }

        val btnPendiente = view.findViewById<Button>(R.id.btnPendiente)
        btnPendiente.setOnClickListener {
            enviarPedidoPendiente(incluirConfirmacion = false)
        }

        val btnImprimir = view.findViewById<Button>(R.id.btnImprimir)
        btnImprimir.setOnClickListener {
            enviarPedidoPendiente(incluirConfirmacion = true)
        }

        val btnCobrar = view.findViewById<Button>(R.id.btnCobrar)
    }

    private fun mostrarCategorias(familias: List<FamiliaProducto>) {
        layoutCategorias.removeAllViews()

        Log.d("ParrillaFragment", "Familias recibidos: $familias")

        familias.filter { it.VISIBLETPV == 1}.sortedBy { it.NOrden }.forEach { familia ->
            val boton = MaterialButton(requireContext()).apply {
                text = familia.Nombre
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    setMargins(8, 8, 8, 8)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }
                isAllCaps = false
                setPadding(12, 24, 12, 24)
                gravity = Gravity.CENTER
                textSize = 14f
                setOnClickListener {
                    mostrarProductosDeFamilia(familia.Nombre)
                }
            }
            layoutCategorias.addView(boton)
        }
    }

    private fun mostrarProductosDeFamilia(nombreFamilia: String) {
        Log.d("producto", productosViewModel.productos.value.toString())
        val productos = productosViewModel.productos.value
            ?.filter { it.Familia == nombreFamilia && it.VISIBLETPV == 1 && it.ColorNet == nombreLocal}
            ?.sortedBy { it.Orden }
            ?: emptyList()

        layoutProductos.removeAllViews()

        for (producto in productos) {
            val btn = MaterialButton(requireContext()).apply {
                text = producto.Producto
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    setMargins(8, 8, 8, 8)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }
                isAllCaps = false
                setPadding(12, 24, 12, 24)
                gravity = Gravity.CENTER
                textSize = 14f
                setOnClickListener {
                    Log.e("hola", producto.Producto)
                    pedidoViewModel.añadirProducto(producto.Producto)
                }
            }
            layoutProductos.addView(btn)
        }
    }

    private fun actualizarUIProductos() {
        layoutTicketItems.removeAllViews()

        val productos = pedidoViewModel.obtenerProductos(mesaActual, salaActual)
        val conteo = productos.groupingBy { it }.eachCount()
        val listaProductos = productosViewModel.productos.value ?: emptyList()
        var total = 0.0

        for ((prod, cantidad) in conteo) {
            val producto = listaProductos.find { it.Producto == prod }
            val precioUnitario = producto?.Tarifa1?.replace(",", ".")?.toDoubleOrNull() ?: 0.0
            val subtotal = cantidad * precioUnitario
            total += subtotal

            val itemLayout = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 4, 0, 4) }
                setPadding(8, 8, 8, 8)
                isClickable = true
                isFocusable = true
                setBackgroundResource(android.R.drawable.list_selector_background)

                setOnClickListener {
                    // Mostrar diálogo de confirmación o quitar directamente
                    AlertDialog.Builder(requireContext())
                        .setTitle("Eliminar producto")
                        .setMessage("¿Quieres eliminar una unidad de $prod del ticket?")
                        .setPositiveButton("Sí") { _, _ ->
                            pedidoViewModel.quitarProducto(prod)
                        }
                        .setNegativeButton("No", null)
                        .show()
                }
            }


            val detalleView = TextView(context).apply {
                text = "$cantidad x $prod"
                setTextColor(Color.BLACK)
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val precioView = TextView(context).apply {
                text = "%.2f €".format(precioUnitario)
                setTextColor(Color.DKGRAY)
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            itemLayout.addView(detalleView)
            itemLayout.addView(precioView)

            layoutTicketItems.addView(itemLayout)
        }

        // Mostrar total en textTotal
        val totalView = view?.findViewById<TextView>(R.id.textTotal)
        totalView?.text = "Total: %.2f €".format(total)
    }

    private fun enviarPedidoPendiente(incluirConfirmacion: Boolean) {
        val mesa = pedidoViewModel.mesaSeleccionada.value ?: "MesaDesconocida"
        val sala = pedidoViewModel.salaSeleccionada.value ?: "SalaDesconocida"
        val productos = pedidoViewModel.obtenerProductos(mesa, sala)
        val sharedPref = requireContext().getSharedPreferences("TPV_PREFS", Context.MODE_PRIVATE)
        val nombreCam = sharedPref.getString("empleado_nombre", "CAMARERA_DESCONOCIDA") ?: "CAMARERA_DESCONOCIDA"
        val idUnicoPedido = pedidoViewModel.obtenerIdPedidoMesaSeleccionada()


        if (productos.isEmpty()) {
            RetrofitClient.apiService.borrarPedido(sharedPref.getString("dbId", "cloud").toString(), idUnicoPedido.toString())
                .enqueue(object : Callback<Void> {
                    override fun onResponse(call: Call<Void>, response: Response<Void>) {
                        if (response.isSuccessful) {
                            Log.i("API", "✅ Pedido $idUnicoPedido borrado correctamente")
                        } else {
                            Log.e("API", "❌ Error al borrar pedido $idUnicoPedido")
                        }
                    }
                    override fun onFailure(call: Call<Void>, t: Throwable) {
                        Log.e("API", "Fallo al borrar pedido $idUnicoPedido", t)
                    }
                })
            return
        }

        val conteo = productos.groupingBy { it }.eachCount()
        val todosLosProductos = productosViewModel.productos.value ?: return

        val now = LocalDateTime.now()
        val formatterFecha = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val formatterHora = DateTimeFormatter.ofPattern("HH:mm:ss")
        val fechaActual = now.format(formatterFecha)
        val horaActual = now.format(formatterHora)

        conteo.forEach { (nombreProducto, cantidad) ->
            val producto = todosLosProductos.find { it.Producto == nombreProducto } ?: return@forEach

            val precio = producto.Tarifa1.replace(",", ".").toDouble()
            val total = cantidad * precio

            val linea = Pedido(
                reg = idUnicoPedido.toString(),
                Hora = horaActual,
                NombreCam = nombreCam,
                NombreFormaPago = sala,
                Fecha = fechaActual,
                FechaReg = fechaActual,
                Barra = 1,
                Terminal = 1,
                Plu = producto.Plu,
                Producto = producto.Producto,
                Cantidad = cantidad.toString(),
                Pts = producto.Tarifa1,
                ImpresoCli = 1,
                Tarifa = producto.Tarifa1,
                CBarras = terminal,
                PagoPerndiente = mesa,
                Comensales = "1",
                Consumo = "1",
                IDCLIENTE = "0A_VENTA",
                NombTerminal = nombreLocal,
                IvaVenta = producto.IvaVenta,
                Iva = producto.IvaVenta,
                TotalReg = total.toString(),
                incluirConfirmacion = incluirConfirmacion
            )

            Log.e("LINEA", "" + linea);

            RetrofitClient.apiService.sincronizarPedido(sharedPref.getString("dbId", "cloud").toString(), idUnicoPedido.toString(), linea).enqueue(object : Callback<Void> {
                override fun onResponse(call: Call<Void>, response: Response<Void>) {
                    if (!response.isSuccessful) {
                        val errorBody = response.errorBody()?.string()
                        Log.e("API", """
                            ❌ Error al guardar producto: ${producto.Producto}
                            Código HTTP: ${response.code()}
                            Respuesta del servidor: $errorBody
                           """.trimIndent())

                        try {
                            val jsonError = JSONObject(errorBody ?: "{}")
                            val mensajeError = jsonError.optString("error", "Error desconocido")
                            Log.e("API", "Mensaje de error: $mensajeError")

                            // Mostrar mensaje en UI (por ejemplo Toast)
                            Toast.makeText(context, mensajeError, Toast.LENGTH_LONG).show()

                        } catch (e: JSONException) {
                            // Si no es JSON válido
                            Log.e("API", "No se pudo parsear el error JSON")
                            Toast.makeText(context, "Error desconocido del servidor", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Log.i("API", "✅ Producto guardado correctamente: ${producto.Producto}")
                    }
                }

                override fun onFailure(call: Call<Void>, t: Throwable) {
                    Log.e("API", "Fallo al enviar producto: ${producto.Producto}", t)
                }
            })
        }

        Toast.makeText(requireContext(), "Productos enviados como pendientes", Toast.LENGTH_SHORT).show()
    }

}