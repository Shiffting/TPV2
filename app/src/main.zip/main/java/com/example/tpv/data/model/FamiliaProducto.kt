package com.example.tpv.data.model

data class FamiliaProducto(
    val N: Int,
    val Nombre: String,
    val NOrden: Int,
    val VISIBLETPV: Int
)