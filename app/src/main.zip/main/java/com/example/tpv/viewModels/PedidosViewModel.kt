package com.example.tpv.viewModels

import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tpv.data.api.RetrofitClient
import es.redsys.paysys.Utils.Log
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import retrofit2.Callback
import java.util.UUID

class PedidoViewModel : ViewModel() {

    private val _mesaSeleccionada = MutableLiveData<String>("sin mesa")
    val mesaSeleccionada: LiveData<String> = _mesaSeleccionada

    private val _salaSeleccionada = MutableLiveData<String?>()
    val salaSeleccionada: LiveData<String?> get() = _salaSeleccionada

    // Mapa sala+mesa -> id del pedido
    private val _idPedidoPorMesa = MutableLiveData<MutableMap<String, String>>(mutableMapOf())
    val idPedidoPorMesa: LiveData<MutableMap<String, String>> = _idPedidoPorMesa

    // Mapa sala+mesa -> lista de productos
    private val _productosPorMesa = MutableLiveData<MutableMap<String, MutableList<String>>>(mutableMapOf())
    val productosPorMesa: LiveData<MutableMap<String, MutableList<String>>> = _productosPorMesa


    fun seleccionarSala(sala: String?) {
        _salaSeleccionada.value = sala
        val clave = claveSalaMesa() ?: return
        val mapaIds = _idPedidoPorMesa.value ?: mutableMapOf()
        if (!mapaIds.containsKey(clave)) {
            val nuevoId = generarIdUnicoPedido()
            mapaIds[clave] = nuevoId
            _idPedidoPorMesa.value = mapaIds
        }
    }

    private fun generarIdUnicoPedido(): String {
        val uuid = UUID.randomUUID().toString()
        val digitsOnly = uuid.filter { it.isDigit() }
        return digitsOnly.take(18) // Adjust length if needed
    }

    private fun claveSalaMesa(): String? {
        val sala = _salaSeleccionada.value ?: return null
        val mesa = _mesaSeleccionada.value ?: return null
        return "$sala-$mesa"
    }

    fun seleccionarMesa(mesa: String) {
        _mesaSeleccionada.value = mesa
        val clave = claveSalaMesa() ?: return

        // Asegura que hay ID asociado
        val mapaIds = _idPedidoPorMesa.value ?: mutableMapOf()
        if (!mapaIds.containsKey(clave)) {
            mapaIds[clave] = generarIdUnicoPedido()
            _idPedidoPorMesa.value = mapaIds
        }

        // Asegura que hay lista de productos
        val mapaProd = _productosPorMesa.value ?: mutableMapOf()
        if (!mapaProd.containsKey(clave)) {
            mapaProd[clave] = mutableListOf()
            _productosPorMesa.value = mapaProd
        }
    }

    fun obtenerIdPedidoMesaSeleccionada(): String? {
        val clave = claveSalaMesa() ?: return null
        return _idPedidoPorMesa.value?.get(clave)
    }

    fun cerrarMesa() {
        val clave = claveSalaMesa() ?: return
        val mapaIds = _idPedidoPorMesa.value ?: return
        if (mapaIds.containsKey(clave)) {
            mapaIds.remove(clave)
            _idPedidoPorMesa.value = mapaIds
        }
    }

    fun añadirProducto(producto: String) {
        val clave = claveSalaMesa() ?: return
        val mapa = _productosPorMesa.value ?: mutableMapOf()
        val lista = mapa.getOrPut(clave) { mutableListOf() }
        lista.add(producto)
        _productosPorMesa.value = mapa
    }

    fun obtenerProductos(mesa: String, sala: String?): List<String> {
        if (sala == null) return emptyList()
        val clave = "$sala-$mesa"
        return _productosPorMesa.value?.get(clave) ?: emptyList()
    }

    fun quitarProducto(nombreProducto: String) {
        val clave = claveSalaMesa() ?: return
        val productosMesa = _productosPorMesa.value?.get(clave)?.toMutableList() ?: return

        val index = productosMesa.indexOfFirst { it == nombreProducto }
        if (index != -1) {
            productosMesa.removeAt(index)
            _productosPorMesa.value = _productosPorMesa.value?.toMutableMap()?.apply {
                put(clave, productosMesa)
            }
        }
    }
}
