package com.example.tpv

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.gridlayout.widget.GridLayout
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.android.material.button.MaterialButton
import com.example.tpv.data.model.Producto
import com.example.tpv.data.api.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.util.Log
import android.widget.Toast
import com.example.tpv.data.model.Sala
import com.example.tpv.viewModels.PedidoViewModel
import com.example.tpv.viewModels.ProductosViewModel


class SalasFragment : Fragment() {

    private val pedidoViewModel: PedidoViewModel by activityViewModels()
    private val viewModel: ProductosViewModel by activityViewModels()

    private lateinit var gridLayoutSalas: GridLayout
    private lateinit var gridLayoutMesas: GridLayout

    private val salaButtons = mutableListOf<MaterialButton>()
    private val mesaButtons = mutableListOf<MaterialButton>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_salas, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        gridLayoutSalas = view.findViewById(R.id.gridLayoutSalas)
        gridLayoutMesas = view.findViewById(R.id.gridLayoutMesas)

        val prefs = requireContext().getSharedPreferences("TPV_PREFS", Context.MODE_PRIVATE)
        val local = prefs.getString("local_nombre", null).toString()

        viewModel.cargarSalas(prefs.getString("dbId", "cloud").toString(), local)

        viewModel.salas.observe(viewLifecycleOwner) { salas ->
            if (salas.isEmpty()) {
                Toast.makeText(requireContext(), "No hay salas disponibles", Toast.LENGTH_SHORT).show()
            }
            gridLayoutSalas.removeAllViews()
            gridLayoutMesas.removeAllViews()
            salaButtons.clear()
            mesaButtons.clear()

            salas.forEach { sala ->
                val salaButton = MaterialButton(requireContext()).apply {
                    text = sala.denominacion
                    isCheckable = true
                    layoutParams = GridLayout.LayoutParams().apply {
                        width = 0
                        height = ViewGroup.LayoutParams.WRAP_CONTENT
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(8, 8, 8, 8)
                    }
                    setOnClickListener {
                        selectExclusive(this, salaButtons)
                        pedidoViewModel.seleccionarSala(sala.denominacion)
                        mostrarMesas(sala)
                        clearMesaSelection(mesaButtons)
                    }
                }

                salaButtons.add(salaButton)
                gridLayoutSalas.addView(salaButton)
            }
        }
    }

    private fun mostrarMesas(sala: Sala) {
        gridLayoutMesas.removeAllViews()
        mesaButtons.clear()

        repeat(sala.numMesas) { index ->
            val mesaButton = MaterialButton(requireContext()).apply {
                text = "Mesa ${index + 1}"
                isCheckable = true
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(8, 8, 8, 8)
                }
                setOnClickListener {
                    selectExclusive(this, mesaButtons)
                    pedidoViewModel.seleccionarMesa(text.toString())
                    println("Mesa seleccionada: ${text}")
                }
            }

            mesaButtons.add(mesaButton)
            gridLayoutMesas.addView(mesaButton)
        }
    }

    private fun selectExclusive(selected: MaterialButton, buttons: List<MaterialButton>) {
            for (btn in buttons) {
                btn.isChecked = btn == selected
            }
        }

    private fun clearMesaSelection(mesaButtons: List<MaterialButton>) {
        for (btn in mesaButtons) {
            btn.isChecked = false
        }
    }
}