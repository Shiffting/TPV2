package com.example.tpv.data.model

data class Empleado(
    val id_camarero: Int,
    val nombre_camarero: String,
    val id_local: String
)