package com.example.tpv.data.model

data class Sala(
    val denominacion: String,
    val tarifa: String,
    val numMesas: Int
)