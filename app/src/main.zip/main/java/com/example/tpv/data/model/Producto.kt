package com.example.tpv.data.model

data class Producto(
    val PLUNUBE: Int,
    val Plu: Int,
    val Producto: String,
    val Familia: String,
    val CodigoFamilia: Int,
    val Tarifa1: String,
    val Tarifa2: String,
    val Tarifa3: String,
    val Tarifa4: String,
    val CBarrasProd: String?,
    val Orden: Int,
    val VISIBLETPV: Int,
    val UsaTapa: Int,
    val TarifaTapa: String,
    val UsaMediaRacion: Int,
    val TarifaMediaRacion: String,
    val IvaVenta: String,
    val ColorNet: String,
    val TotalReg: String,
    val CBarras: String,
    val IDCLIENTE: String,
    val NombTerminal: String,
    val Cantidad: String
)