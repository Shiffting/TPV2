package com.example.tpv.data.model

data class Terminal(
    val id_terminal: Int,
    val nombre_terminal: String,
    val id_local: Int
)