package com.example.tpv.data.model

data class Local(
    val id_local: Int,
    val nombre_local: String
)