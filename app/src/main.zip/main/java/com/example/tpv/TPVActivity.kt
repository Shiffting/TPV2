package com.example.tpv

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class TPVActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_tpvactivity)

        // Cargar fragmento inicial
        loadFragment(SalasFragment())

        // Setup menú
        findViewById<ImageButton>(R.id.btnSalas).setOnClickListener {
            loadFragment(SalasFragment())
        }
        findViewById<ImageButton>(R.id.btnParrilla).setOnClickListener {
            loadFragment(ParrillaFragment())
        }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            loadFragment(SettingsFragment())
        }
        findViewById<ImageButton>(R.id.btnDisconnect).setOnClickListener {
            //TODO disconnect
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.activity_content, fragment)
            .commit()
    }


}
